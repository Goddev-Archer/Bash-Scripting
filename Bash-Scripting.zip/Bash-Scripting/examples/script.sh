for datei in *.jpg; do
    neuername="${datei%jpg}JPG"
    mv $datei $neuername
done